import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'emerald';
}

const Logo: React.FC<LogoProps> = ({ className = "w-8 h-8", variant = 'emerald' }) => {
  const colors = {
    light: '#FFFFFF',
    dark: '#1E1E1E',
    emerald: '#10b981'
  };

  const primaryColor = colors[variant];

  return (
    <svg 
      viewBox="0 0 100 100" 
      className={className} 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* The "Stack" - Three precise geometric bars representing industrial infrastructure */}
      <rect x="25" y="45" width="8" height="35" fill={primaryColor} rx="1" />
      <rect x="38" y="30" width="8" height="50" fill={primaryColor} rx="1" />
      <rect x="51" y="55" width="8" height="25" fill={primaryColor} rx="1" />
      
      {/* The "Zero" (Ø) - A bold circular loop symbolizing the elimination of emissions and circularity */}
      <circle 
        cx="50" 
        cy="50" 
        r="38" 
        stroke={primaryColor} 
        strokeWidth="10" 
        strokeLinecap="square"
        strokeDasharray="180 60"
      />
      
      {/* The Intersection Bar - Making it a true 'Ø' symbol with a sharp technical edge */}
      <path 
        d="M30 70L70 30" 
        stroke={primaryColor} 
        strokeWidth="8" 
        strokeLinecap="square" 
      />
    </svg>
  );
};

export default Logo;