
import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Globe, 
  ExternalLink, 
  Filter,
  CheckCircle,
  Tag,
  DollarSign,
  TrendingDown,
  Zap,
  ShieldCheck,
  Cpu,
  HelpCircle,
  Lightbulb
} from 'lucide-react';
import { MOCK_INCENTIVES } from '../constants';

const Incentives: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [showFramework, setShowFramework] = useState(true);

  const filtered = MOCK_INCENTIVES.filter(inc => 
    (inc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     inc.country.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (filterType === 'All' || inc.type === filterType)
  );

  const frameworks = [
    {
      title: "Tax Breaks & Relief",
      icon: <DollarSign className="w-5 h-5 text-blue-500" />,
      items: [
        { label: "Investment Tax Credit (ITC)", desc: "Direct subtraction from taxes for clean-tech equipment installs." },
        { label: "Accelerated Depreciation", desc: "Write off green equipment costs faster to reduce taxable income." },
        { label: "Production Tax Credit (PTC)", desc: "Credits earned based on clean energy volume generated." },
        { label: "Carbon Tax Relief", desc: "Lowered or zero tax for verified low-emission industries." }
      ]
    },
    {
      title: "Direct Subsidies",
      icon: <Zap className="w-5 h-5 text-emerald-500" />,
      items: [
        { label: "Grants & Funding", desc: "Direct capital for hydrogen, carbon capture, or EV factory projects." },
        { label: "Low-Interest Loans", desc: "Cheaper capital from green banks for infra investment." },
        { label: "Feed-in Tariffs", desc: "Guaranteed fixed prices for renewable energy fed into the grid." },
        { label: "Subsidized R&D", desc: "Support for green-tech innovation and early-stage research." }
      ]
    }
  ];

  return (
    <div className="space-y-10 pb-20 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Global Incentives</h1>
          <p className="text-slate-500 mt-2 font-medium">Strategic funding opportunities for Net-Zero industrial infrastructure.</p>
        </div>
        <button 
          onClick={() => setShowFramework(!showFramework)}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-colors shadow-sm"
        >
          <HelpCircle className="w-4 h-4" />
          {showFramework ? 'Hide Framework' : 'Financial Framework'}
        </button>
      </header>

      {/* Financial Framework Guide */}
      {showFramework && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in slide-in-from-top-4 duration-500">
          {frameworks.map((section, idx) => (
            <div key={idx} className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform duration-700 pointer-events-none">
                {section.icon}
              </div>
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  {section.icon}
                </div>
                <h3 className="text-xl font-black text-slate-900">{section.title}</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {section.items.map((item, i) => (
                  <div key={i} className="p-4 bg-slate-50/50 rounded-2xl border border-slate-100/50 hover:bg-white hover:border-emerald-200 transition-all cursor-default">
                    <p className="text-xs font-black text-slate-800 uppercase tracking-tight mb-1">{item.label}</p>
                    <p className="text-[11px] text-slate-500 leading-relaxed font-medium">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Hero Visualizer */}
      <div className="bg-[#121212] rounded-[2.5rem] p-10 h-72 relative overflow-hidden group border border-white/5 shadow-2xl">
        <div className="absolute inset-0 opacity-[0.05] pointer-events-none">
          <Globe className="w-[600px] h-[600px] absolute -right-40 -top-40 text-emerald-400 animate-spin-slow" />
        </div>
        <div className="relative z-10 flex flex-col justify-center h-full max-w-2xl">
          <div className="flex items-center gap-2 mb-4">
            <Cpu className="w-4 h-4 text-emerald-500" />
            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.4em]">Aggregator Engine</span>
          </div>
          <h2 className="text-4xl font-black text-white leading-tight">Identify regional funding and tax breaks for your facility.</h2>
          <div className="mt-8 flex gap-6">
            <div className="flex flex-col">
              <span className="text-3xl font-black text-emerald-400">128</span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Programs</span>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div className="flex flex-col">
              <span className="text-3xl font-black text-white">$1.2B</span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Total Liquidity</span>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div className="flex flex-col">
              <span className="text-3xl font-black text-blue-400">22</span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Market Incentives</span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col lg:flex-row gap-6 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search by country, program, or keyword..."
            className="w-full bg-white border border-slate-200 rounded-[1.5rem] py-5 pl-14 pr-6 focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all shadow-sm font-medium text-slate-700"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto w-full lg:w-auto p-1 bg-slate-100 rounded-[1.5rem] border border-slate-200">
          {['All', 'Grant', 'Tax Credit', 'Subsidy', 'Loan', 'Tariff', 'R&D'].map(type => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`
                whitespace-nowrap px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all
                ${filterType === type ? 'bg-white text-slate-900 shadow-md border-slate-200' : 'text-slate-400 hover:text-slate-600'}
              `}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Incentives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map(inc => (
          <div key={inc.id} className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm hover:shadow-xl hover:border-emerald-200 transition-all group flex flex-col relative overflow-hidden">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-2.5 bg-slate-50 px-4 py-2 rounded-xl text-[10px] font-black text-slate-500 uppercase tracking-[0.1em] border border-slate-100">
                <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                {inc.country}
              </div>
              <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${
                inc.type === 'Tax Credit' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                inc.type === 'Grant' ? 'bg-purple-50 text-purple-600 border-purple-100' : 
                inc.type === 'Tariff' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                'bg-emerald-50 text-emerald-600 border-emerald-100'
              }`}>
                {inc.type}
              </span>
            </div>

            <h3 className="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors mb-4 leading-tight">
              {inc.name}
            </h3>
            
            <div className="mb-6 flex flex-col">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Benefit Calculation</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-slate-900 tracking-tighter">{inc.amount}</span>
              </div>
            </div>

            <div className="space-y-4 mb-10 flex-1">
              <div className="flex items-start gap-3 bg-slate-50/50 p-4 rounded-2xl border border-slate-100/50">
                <ShieldCheck className="w-5 h-5 text-emerald-500 mt-0.5 shrink-0" />
                <p className="text-xs text-slate-600 leading-relaxed font-medium">{inc.eligibility}</p>
              </div>
            </div>

            <a 
              href={inc.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="mt-auto w-full flex items-center justify-center gap-3 bg-[#1E1E1E] text-white py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:bg-emerald-600 transition-all shadow-lg hover:shadow-emerald-500/20"
            >
              Verify Compliance <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-24 bg-white rounded-[3rem] border border-dashed border-slate-200">
          <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Search className="w-8 h-8 text-slate-300" />
          </div>
          <h3 className="text-2xl font-black text-slate-900">Program Not Found</h3>
          <p className="text-slate-500 max-w-xs mx-auto mt-2 font-medium">We couldn't find any financial instruments matching your current search parameters.</p>
          <button 
            onClick={() => {setSearchTerm(''); setFilterType('All');}}
            className="mt-8 text-emerald-600 font-black uppercase text-xs tracking-widest"
          >
            Reset All Filters
          </button>
        </div>
      )}
    </div>
  );
};

export default Incentives;
