import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Info, 
  Clock, 
  Wind, 
  Zap, 
  Thermometer, 
  Smile, 
  Frown,
  Bell,
  Cloud,
  Flame,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { POLLUTION_THRESHOLDS } from '../constants';
import { SensorData } from '../types';
import Logo from './Logo';

const Dashboard: React.FC = () => {
  const [data, setData] = useState<SensorData>({
    pm25: 12,
    voc: 320,
    no2: 24,
    so2: 8,
    o3: 45,
    co: 0.8,
    co2: 415,
    temp: 22.5,
    timestamp: new Date().toLocaleTimeString()
  });

  const [alertThreshold, setAlertThreshold] = useState(50);
  const [hasAlert, setHasAlert] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => {
        const newData = {
          ...prev,
          pm25: Math.max(0, prev.pm25 + (Math.random() - 0.5) * 8),
          voc: Math.max(0, prev.voc + (Math.random() - 0.5) * 60),
          no2: Math.max(0, prev.no2 + (Math.random() - 0.5) * 6),
          so2: Math.max(0, prev.so2 + (Math.random() - 0.5) * 4),
          co2: Math.max(400, prev.co2 + (Math.random() - 0.5) * 30),
          timestamp: new Date().toLocaleTimeString()
        };
        setHasAlert(newData.pm25 > alertThreshold);
        return newData;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [alertThreshold]);

  const getStatusColor = (value: number, type: keyof typeof POLLUTION_THRESHOLDS) => {
    const t = POLLUTION_THRESHOLDS[type];
    if (value > t.high) return 'text-red-600 bg-red-100 border-red-200';
    if (value > t.moderate) return 'text-yellow-600 bg-yellow-100 border-yellow-200';
    return 'text-emerald-600 bg-emerald-100 border-emerald-200';
  };

  const getGaugeColor = (value: number, type: keyof typeof POLLUTION_THRESHOLDS) => {
    const t = POLLUTION_THRESHOLDS[type];
    if (value > t.high) return 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]';
    if (value > t.moderate) return 'bg-yellow-500 shadow-[0_0_15px_rgba(245,158,11,0.5)]';
    return 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]';
  };

  const getHealthTip = (value: number, type: keyof typeof POLLUTION_THRESHOLDS) => {
    const t = POLLUTION_THRESHOLDS[type];
    
    if (type === 'co2') {
      if (value > 1500) return `Danger: Critical CO2 levels (>1500ppm). Significant risk of headaches and severe loss of focus.`;
      if (value > 1000) return `Caution: Elevated CO2 (1000-1500ppm). Associated with drowsiness and reduced cognitive performance.`;
      if (value > 600) return `Acceptable: Standard indoor CO2 (600-1000ppm). Maintain current ventilation levels.`;
      return `Optimal: Excellent CO2 (<600ppm). Near outdoor air quality levels.`;
    }

    if (value > t.high) return `Danger: ${t.label} levels critical. Prolonged exposure may cause severe health issues. Activate filtration systems.`;
    if (value > t.moderate) return `Warning: ${t.label} is slightly elevated. May cause discomfort for sensitive individuals.`;
    return `Excellent: ${t.label} is within safe WHO guidelines. No action required.`;
  };

  return (
    <div className={`space-y-10 transition-all duration-700 ${hasAlert ? 'ring-8 ring-red-500/10 ring-inset' : ''}`}>
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Secure Industrial Node</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Operational Dashboard</h1>
          <div className="flex items-center gap-6 mt-2">
            <p className="text-slate-500 flex items-center gap-2 font-medium">
              <Clock className="w-4 h-4 text-slate-400" /> System Time: {data.timestamp}
            </p>
            <div className="flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
               <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Sensors Live</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4 bg-white p-3 rounded-2xl border shadow-sm">
          <label className="text-xs font-black text-slate-400 px-2 flex items-center gap-2 uppercase tracking-tighter">
            <Bell className="w-4 h-4 text-slate-300" /> Warning Threshold
          </label>
          <input 
            type="range" 
            min="10" 
            max="150" 
            value={alertThreshold} 
            onChange={(e) => setAlertThreshold(Number(e.target.value))}
            className="w-32 h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />
          <span className="text-sm font-black bg-slate-100 px-3 py-1 rounded-lg text-slate-700">{alertThreshold}</span>
        </div>
      </header>

      {/* Hero Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 relative overflow-hidden bg-[#121212] rounded-[2.5rem] p-10 text-white shadow-2xl border border-white/5">
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
          
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Logo className="w-6 h-6" variant="emerald" />
                <span className="text-xs font-black tracking-[0.4em] text-emerald-500 uppercase">System Intelligence</span>
              </div>
              <h2 className="text-lg font-bold text-slate-400 uppercase tracking-widest mb-2">Active Air Quality Index</h2>
              <div className="flex items-baseline gap-4">
                <span className="text-8xl font-black tracking-tighter transition-all duration-700">{data.pm25 < 35 ? 'GOOD' : 'FAIR'}</span>
                <span className={`text-3xl font-bold px-4 py-1 rounded-2xl border transition-all duration-700 ${data.pm25 < 35 ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' : 'text-amber-500 bg-amber-500/10 border-amber-500/20'}`}>
                  AQI {Math.round(data.pm25 * 1.5)}
                </span>
              </div>
            </div>
            
            <div className="mt-12 grid grid-cols-2 gap-6 max-w-lg">
              <div className="bg-white/5 backdrop-blur-2xl rounded-3xl p-6 border border-white/10 flex items-center gap-4 hover:bg-white/10 transition-colors group">
                <div className="bg-orange-500/20 p-3 rounded-2xl"><Thermometer className="w-6 h-6 text-orange-400" /></div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-slate-500">Facility Temp</p>
                  <p className="text-2xl font-black transition-all duration-500 group-hover:text-orange-400">{data.temp.toFixed(1)}°C</p>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-2xl rounded-3xl p-6 border border-white/10 flex items-center gap-4 hover:bg-white/10 transition-colors group">
                <div className="bg-blue-500/20 p-3 rounded-2xl"><Wind className="w-6 h-6 text-blue-400" /></div>
                <div>
                  <p className="text-[10px] uppercase font-black tracking-widest text-slate-500">Air Humidity</p>
                  <p className="text-2xl font-black transition-all duration-500 group-hover:text-blue-400">42.8%</p>
                </div>
              </div>
            </div>
          </div>

          <div className="absolute top-10 right-10 animate-float flex flex-col items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-emerald-500/20 blur-3xl rounded-full" />
              {data.pm25 < 35 && data.co2 < 800 ? (
                <div className="relative flex flex-col items-center">
                  <Smile className="w-24 h-24 text-emerald-400 drop-shadow-[0_0_15px_rgba(16,185,129,0.5)]" />
                  <div className="mt-4 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-xs font-black text-emerald-400 uppercase tracking-widest">
                    Optimal Output
                  </div>
                </div>
              ) : (
                <div className="relative flex flex-col items-center">
                  <Frown className="w-24 h-24 text-rose-400 drop-shadow-[0_0_15px_rgba(244,63,94,0.5)]" />
                  <div className="mt-4 px-4 py-2 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-xs font-black text-rose-400 uppercase tracking-widest">
                    Intervention Required
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] p-10 border shadow-sm flex flex-col justify-center items-center text-center space-y-6 hover:shadow-xl transition-shadow border-slate-100">
           <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100">
             <Logo className="w-12 h-12" variant="emerald" />
           </div>
           <div>
             <h3 className="text-2xl font-black text-slate-900 leading-tight">Environmental Core</h3>
             <p className="text-slate-500 text-sm mt-3 leading-relaxed font-medium">
               {data.co2 < 600 && data.so2 < 20 
                 ? "STACKZERO confirms all industrial outputs are currently within Net-Zero compliance thresholds." 
                 : "Environmental systems monitoring active. Automated scrubbers calibrated to current throughput."}
             </p>
           </div>
           <button className="flex items-center gap-2 text-emerald-600 text-xs font-black uppercase tracking-widest bg-emerald-50 px-6 py-3 rounded-xl border border-emerald-100 hover:bg-emerald-100 transition-colors">
             Run Full Diagnostics <ChevronRight className="w-4 h-4" />
           </button>
        </div>
      </div>

      {/* Sensor Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {[
          { key: 'pm25' as const, icon: Wind, label: 'Fine Dust' },
          { key: 'voc' as const, icon: Zap, label: 'Volatiles' },
          { key: 'no2' as const, icon: AlertTriangle, label: 'Nitrogen' },
          { key: 'so2' as const, icon: Flame, label: 'Sulfur' },
          { key: 'co2' as const, icon: Cloud, label: 'Carbon' }
        ].map(({ key, icon: Icon, label }) => {
          const value = data[key];
          const threshold = POLLUTION_THRESHOLDS[key];
          const percent = Math.min(100, (value / threshold.high) * 100);
          
          return (
            <div key={key} className="bg-white rounded-3xl p-8 border shadow-sm hover:border-emerald-200 transition-all group relative overflow-visible flex flex-col h-full">
              <div className="flex justify-between items-start mb-6">
                <div className={`p-4 rounded-2xl transition-all duration-500 group-hover:scale-110 ${getStatusColor(value, key)}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border border-slate-100 cursor-help group-hover:bg-slate-100 transition-colors">
                  <Info className="w-3.5 h-3.5" /> {threshold.unit}
                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-4 left-1/2 -translate-x-1/2 w-64 bg-[#1E1E1E] text-white text-[11px] p-5 rounded-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all z-50 shadow-2xl font-normal normal-case text-center leading-relaxed border border-white/10">
                    <p className="font-black text-emerald-400 mb-2 uppercase tracking-widest">{threshold.label} HEALTH IMPACT</p>
                    <p className="opacity-80 leading-relaxed">{getHealthTip(value, key)}</p>
                    <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-[#1E1E1E]"></div>
                  </div>
                </div>
              </div>
              
              <div className="flex-1">
                <h4 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">{threshold.label}</h4>
                <p className="text-slate-500 text-xs font-bold mb-2 opacity-60 uppercase">{label} Index</p>
                <div className="mt-1 mb-6 flex items-baseline gap-2">
                  <span className="text-5xl font-black text-slate-900 tracking-tighter transition-all duration-1000">
                    {value.toFixed(0)}
                  </span>
                  <span className="text-slate-400 text-sm font-bold">{threshold.unit}</span>
                </div>
              </div>

              <div className="mt-auto relative pb-6">
                <div className="relative h-2 w-full bg-slate-50 rounded-full overflow-hidden border border-slate-100">
                  <div 
                    className={`absolute top-0 left-0 h-full transition-all duration-[2000ms] ease-out rounded-full ${getGaugeColor(value, key)}`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
                
                {/* Needle / Marker Indicator */}
                <div 
                  className="absolute top-[-4px] h-4 w-1 bg-slate-900 rounded-full transition-all duration-[2000ms] ease-out shadow-sm border border-white/20 z-10"
                  style={{ left: `calc(${percent}% - 2px)` }}
                />

                <div className="flex justify-between mt-4 text-[9px] font-black text-slate-400 uppercase tracking-[0.15em]">
                  <span className={`transition-colors duration-1000 ${percent < 40 ? 'text-emerald-500 font-black' : ''}`}>Safe</span>
                  <span className={`transition-colors duration-1000 ${percent >= 40 && percent < 80 ? 'text-amber-500 font-black' : ''}`}>Caution</span>
                  <span className={`transition-colors duration-1000 ${percent >= 80 ? 'text-rose-500 font-black animate-pulse' : ''}`}>Danger</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Alerts */}
      {hasAlert && (
        <div className="bg-[#1E1E1E] border border-rose-500/30 rounded-3xl p-8 flex items-center gap-6 animate-pulse shadow-2xl">
          <div className="bg-rose-500 p-4 rounded-2xl text-white shadow-[0_0_20px_rgba(244,63,94,0.4)]">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <div>
            <h4 className="font-black text-white uppercase tracking-widest text-lg">Industrial Safety Protocol Override</h4>
            <p className="text-slate-400 text-sm mt-1">PM2.5 levels detected at <span className="text-rose-400 font-bold">{data.pm25.toFixed(1)} µg/m³</span>. Threshold exceeded ({alertThreshold}). Auto-scrubbing sequence recommended.</p>
          </div>
          <button className="ml-auto bg-rose-500 hover:bg-rose-600 text-white font-black px-6 py-3 rounded-xl transition-colors text-xs uppercase tracking-widest">
            Acknowledge
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;