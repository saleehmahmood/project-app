import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Sparkles, 
  Image as ImageIcon, 
  RefreshCw, 
  Download, 
  ChevronRight,
  ShieldCheck,
  Zap,
  Layout
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import Logo from './Logo';

const ImageStudio: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSourceImage(reader.result as string);
        setResultImage(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateEdit = async () => {
    if (!sourceImage || !prompt) return;

    setIsGenerating(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const base64Data = sourceImage.split(',')[1];
      const mimeType = sourceImage.split(';')[0].split(':')[1];

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType,
              },
            },
            {
              text: `Professional industrial rendering edit: ${prompt}. Maintain technical accuracy and enterprise-grade aesthetics.`,
            },
          ],
        },
      });

      let foundImage = false;
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setResultImage(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
          foundImage = true;
          break;
        }
      }

      if (!foundImage) {
        setError("Generation completed but no image was returned. Try a more specific prompt.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during generation.");
    } finally {
      setIsGenerating(false);
    }
  };

  const quickPrompts = [
    "Add industrial solar panel arrays to the roof",
    "Replace smoke emissions with clean condensation",
    "Add a surrounding green buffer zone with trees",
    "Apply a clean, high-tech industrial filter",
    "Visualize the facility at night with eco-friendly LED lighting"
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Nano Banana Engine</span>
          </div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Visual Studio</h1>
          <p className="text-slate-500 mt-2 font-medium max-w-xl">
            Transform facility documentation into Net-Zero investor visuals. Use AI to visualize infrastructure upgrades and environmental impact.
          </p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls Panel */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b">
              <div className="bg-[#121212] p-2 rounded-xl">
                <Logo className="w-5 h-5" variant="emerald" />
              </div>
              <h3 className="font-bold text-slate-800">Design Parameters</h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block">1. Source Asset</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`
                    cursor-pointer group relative overflow-hidden border-2 border-dashed rounded-[1.5rem] transition-all p-8 text-center
                    ${sourceImage ? 'border-emerald-500/20 bg-emerald-50/10' : 'border-slate-200 hover:border-emerald-500 hover:bg-slate-50'}
                  `}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileUpload} 
                  />
                  {sourceImage ? (
                    <div className="space-y-2">
                      <ShieldCheck className="w-8 h-8 text-emerald-500 mx-auto" />
                      <p className="text-xs font-bold text-slate-600">Asset Loaded</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="w-8 h-8 text-slate-300 mx-auto group-hover:text-emerald-500 transition-colors" />
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-tight">Upload Facility Photo</p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block">2. Transformation Prompt</label>
                <textarea 
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g., 'Modernize the stacks with carbon capture units and add vertical wind turbines'..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm font-medium outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all min-h-[120px] resize-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Quick Suggestions</label>
                <div className="flex flex-wrap gap-2">
                  {quickPrompts.map((p, i) => (
                    <button 
                      key={i} 
                      onClick={() => setPrompt(p)}
                      className="text-[10px] font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition-colors text-left"
                    >
                      + {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button 
              onClick={generateEdit}
              disabled={isGenerating || !sourceImage || !prompt}
              className={`
                w-full py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all
                ${isGenerating || !sourceImage || !prompt 
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                  : 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20 hover:bg-emerald-700 hover:-translate-y-0.5'}
              `}
            >
              {isGenerating ? (
                <><RefreshCw className="w-4 h-4 animate-spin" /> Engineering Visuals...</>
              ) : (
                <><Sparkles className="w-4 h-4" /> Execute Transformation</>
              )}
            </button>
            
            {error && (
              <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-[10px] font-bold uppercase">
                {error}
              </div>
            )}
          </div>

          <div className="bg-[#121212] rounded-[2rem] p-8 text-white border border-white/5 relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Compliance Ready</span>
              </div>
              <p className="text-sm font-medium leading-relaxed opacity-80">
                Visualizations generated here are designed for investor pitch decks and internal regulatory alignment reports.
              </p>
            </div>
            <Layout className="absolute -right-8 -bottom-8 w-40 h-40 opacity-[0.03] group-hover:scale-110 transition-transform duration-1000" />
          </div>
        </div>

        {/* Canvas Area */}
        <div className="lg:col-span-8 space-y-8">
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden min-h-[600px] flex flex-col">
            <div className="p-6 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Rendering Canvas</span>
                </div>
                {resultImage && (
                  <div className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest">
                    AI Enhanced
                  </div>
                )}
              </div>
              {resultImage && (
                <button 
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = resultImage;
                    link.download = 'stackzero-visualization.png';
                    link.click();
                  }}
                  className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-900 bg-white border px-4 py-2 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" /> Download Asset
                </button>
              )}
            </div>

            <div className="flex-1 p-8 bg-slate-100/30 flex flex-col lg:flex-row gap-8 items-stretch">
              {/* Before Column */}
              <div className="flex-1 flex flex-col space-y-4">
                <div className="flex items-center justify-between px-2">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Initial State</span>
                </div>
                <div className="flex-1 rounded-[1.5rem] bg-white border border-slate-200 overflow-hidden flex items-center justify-center min-h-[300px] relative group">
                  {sourceImage ? (
                    <img src={sourceImage} className="w-full h-full object-cover" alt="Source" />
                  ) : (
                    <div className="text-center p-12 space-y-4">
                      <ImageIcon className="w-12 h-12 text-slate-200 mx-auto" />
                      <p className="text-xs font-black text-slate-300 uppercase tracking-widest">Awaiting Asset Upload</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="hidden lg:flex items-center justify-center">
                <ChevronRight className="w-8 h-8 text-slate-200" />
              </div>

              {/* After Column */}
              <div className="flex-1 flex flex-col space-y-4">
                <div className="flex items-center justify-between px-2">
                  <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Projected Outcome</span>
                </div>
                <div className="flex-1 rounded-[1.5rem] bg-white border-2 border-dashed border-slate-200 overflow-hidden flex items-center justify-center min-h-[300px] relative">
                  {isGenerating && (
                    <div className="absolute inset-0 z-20 bg-emerald-950/20 backdrop-blur-md flex flex-col items-center justify-center p-12 text-center animate-in fade-in">
                       <div className="bg-white p-6 rounded-full shadow-2xl mb-6">
                         <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin" />
                       </div>
                       <h4 className="text-white text-xl font-black uppercase tracking-tighter mb-2">Simulating Future Infrastructure</h4>
                       <p className="text-white/80 text-xs font-medium max-w-xs leading-relaxed">
                         Applying requested modifications using Gemini industrial-vision protocols.
                       </p>
                    </div>
                  )}
                  {resultImage ? (
                    <img src={resultImage} className="w-full h-full object-cover animate-in fade-in slide-in-from-bottom-4 duration-1000" alt="Result" />
                  ) : (
                    <div className="text-center p-12 space-y-4 opacity-30">
                      <Sparkles className="w-12 h-12 text-slate-300 mx-auto" />
                      <p className="text-xs font-black text-slate-300 uppercase tracking-widest">Execute Transformation to View</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="p-8 border-t border-slate-50 flex items-center gap-6">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Technical Summary</p>
                <p className="text-xs text-slate-600 font-medium leading-relaxed">
                  Generative results provide an architectural projection of environmental impact. For high-fidelity CAD/BIM integration, export these visualizations into the STACKZERO engineering pipeline.
                </p>
              </div>
              <div className="flex items-center gap-2 px-6 py-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                 <ShieldCheck className="w-5 h-5 text-emerald-600" />
                 <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">Verified by AI-Core</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageStudio;