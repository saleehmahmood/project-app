import React, { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as ReTooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  LineChart,
  Line
} from 'recharts';
import { 
  DollarSign, 
  Calculator, 
  TrendingUp, 
  Coins, 
  ArrowRight,
  Info,
  Banknote,
  Trees,
  ShieldCheck,
  Zap,
  Layout,
  PieChart as PieChartIcon
} from 'lucide-react';

const Finance: React.FC = () => {
  const [tons, setTons] = useState(10000);
  const [creditPrice, setCreditPrice] = useState(6.5);
  const [taxCreditRate, setTaxCreditRate] = useState(85);
  const [opCostPerTon, setOpCostPerTon] = useState(40);
  const [capitalExpenditure, setCapitalExpenditure] = useState(2500000);

  const stats = useMemo(() => {
    const marketRevenue = tons * creditPrice;
    const taxIncentives = tons * taxCreditRate;
    const totalGross = marketRevenue + taxIncentives;
    const totalCosts = tons * opCostPerTon;
    const netGain = totalGross - totalCosts;
    const paybackPeriod = capitalExpenditure / netGain;
    const roi = (netGain / capitalExpenditure) * 100;

    return { marketRevenue, taxIncentives, totalGross, totalCosts, netGain, roi, paybackPeriod };
  }, [tons, creditPrice, taxCreditRate, opCostPerTon, capitalExpenditure]);

  const chartData = [
    { name: 'Revenue', value: stats.totalGross },
    { name: 'Operating Cost', value: stats.totalCosts },
    { name: 'Net Profit', value: stats.netGain },
  ];

  const pieData = [
    { name: 'Market Sales', value: stats.marketRevenue, color: '#10b981' },
    { name: 'Tax Credits', value: stats.taxIncentives, color: '#3b82f6' },
  ];

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="space-y-10 pb-20 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none">Financial Modeler</h1>
          <p className="text-slate-500 mt-2 font-medium">Calculate the economic viability of carbon capture systems and ROI timelines.</p>
        </div>
        <div className="flex items-center gap-3 bg-white p-3 rounded-2xl border shadow-sm">
           <ShieldCheck className="w-5 h-5 text-emerald-500" />
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Market Feed: Active</span>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Assumption Engine */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b">
              <div className="bg-emerald-100 p-2 rounded-xl">
                <Calculator className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="font-bold text-slate-800">Assumption Engine</h3>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Capital Exp (CAPEX)</label>
                  <span className="text-slate-900 font-black">{formatCurrency(capitalExpenditure)}</span>
                </div>
                <input 
                  type="range" min="500000" max="10000000" step="100000" value={capitalExpenditure}
                  onChange={(e) => setCapitalExpenditure(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CO₂ Captured (Tons/Yr)</label>
                  <span className="text-emerald-600 font-black">{tons.toLocaleString()}</span>
                </div>
                <input 
                  type="range" min="1000" max="100000" step="1000" value={tons}
                  onChange={(e) => setTons(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Credit Price ($/Ton)</label>
                  <span className="text-blue-600 font-black">${creditPrice}</span>
                </div>
                <input 
                  type="range" min="1" max="20" step="0.5" value={creditPrice}
                  onChange={(e) => setCreditPrice(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">OpEx Per Ton ($)</label>
                  <span className="text-rose-600 font-black">${opCostPerTon}</span>
                </div>
                <input 
                  type="range" min="10" max="150" step="5" value={opCostPerTon}
                  onChange={(e) => setOpCostPerTon(Number(e.target.value))}
                  className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-500"
                />
              </div>

              <div className="pt-4 p-5 bg-slate-50 rounded-[1.5rem] border border-slate-100">
                 <div className="flex items-center gap-2 mb-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                   <Info className="w-3.5 h-3.5" /> Market Intelligence
                 </div>
                 <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                   "Model assumes current US Section 45Q credits. Projections may vary based on sequestration vs utilization methods."
                 </p>
              </div>
            </div>
          </div>
          
          <div className="bg-[#121212] rounded-[2rem] p-8 text-white border border-white/5 relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-4 h-4 text-emerald-500" />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Insight Engine</span>
              </div>
              <h4 className="text-lg font-bold mb-2">Investment Strategy</h4>
              <p className="text-sm text-slate-400 leading-relaxed font-medium">
                {stats.roi > 15 
                  ? "This configuration represents a high-efficiency model with an aggressive ROI. Recommend pursuing tax-equity partnerships." 
                  : "Low margin detected. Consider optimizing facility throughput or seeking additional municipal grants."}
              </p>
            </div>
            <Layout className="absolute -right-8 -bottom-8 w-40 h-40 opacity-[0.03] group-hover:scale-110 transition-transform duration-1000" />
          </div>
        </div>

        {/* Right: Results & Insights */}
        <div className="lg:col-span-8 space-y-8">
          {/* Summary Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-emerald-600 rounded-[2rem] p-8 text-white shadow-xl relative overflow-hidden group">
              <div className="relative z-10">
                <div className="flex items-center gap-2 text-emerald-200 text-[10px] font-black uppercase tracking-widest mb-3">
                  <Banknote className="w-4 h-4" /> Gross Revenue
                </div>
                <div className="text-4xl font-black tracking-tighter">{formatCurrency(stats.totalGross)}</div>
                <p className="text-[10px] text-emerald-200/60 mt-4 font-black uppercase tracking-widest">Annualized Estimate</p>
              </div>
              <div className="absolute -right-4 -bottom-4 p-8 opacity-10 group-hover:rotate-12 transition-transform duration-700">
                <TrendingUp className="w-24 h-24 text-white" />
              </div>
            </div>

            <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm group">
              <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest mb-3">
                <TrendingUp className="w-4 h-4" /> Project ROI
              </div>
              <div className={`text-4xl font-black tracking-tighter ${stats.roi > 20 ? 'text-emerald-500' : 'text-slate-900'}`}>
                {stats.roi.toFixed(1)}%
              </div>
              <div className="mt-4 pt-4 border-t border-slate-50 flex justify-between items-center">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Risk Adjusted</span>
                <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-[9px] font-black">Moderate</span>
              </div>
            </div>

            <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm group">
              <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest mb-3">
                <Layout className="w-4 h-4" /> Payback period
              </div>
              <div className="text-4xl font-black tracking-tighter text-slate-900">
                {stats.paybackPeriod.toFixed(1)} <span className="text-lg text-slate-400">Yrs</span>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-50 flex justify-between items-center">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Break-Even point</span>
                <span className="text-emerald-500 text-[9px] font-black">Q{Math.ceil((stats.paybackPeriod % 1) * 4)} {(new Date().getFullYear() + Math.floor(stats.paybackPeriod))}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Bar Chart */}
            <div className="bg-white rounded-[2.5rem] p-10 border border-slate-100 shadow-sm">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h4 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-1">Impact Analysis</h4>
                  <p className="text-[10px] font-medium text-slate-400 uppercase tracking-widest">Revenue vs Operational costs</p>
                </div>
                <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                  <Coins className="w-4 h-4 text-slate-400" />
                </div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 700, fill: '#94a3b8'}} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 9, fill: '#94a3b8'}} />
                    <ReTooltip cursor={{fill: 'rgba(16,185,129,0.05)'}} contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', background: '#1e293b', color: '#fff'}} />
                    <Bar dataKey="value" radius={[12, 12, 0, 0]} barSize={48}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.name === 'Operating Cost' ? '#f43f5e' : entry.name === 'Net Profit' ? '#10b981' : '#3b82f6'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Pie Chart */}
            <div className="bg-white rounded-[2.5rem] p-10 border border-slate-100 shadow-sm">
               <div className="flex justify-between items-start mb-8">
                  <div>
                    <h4 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-1">Source breakdown</h4>
                    <p className="text-[10px] font-medium text-slate-400 uppercase tracking-widest">Revenue diversification</p>
                  </div>
                  <div className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <PieChartIcon className="w-4 h-4 text-slate-400" />
                  </div>
               </div>
               <div className="h-64 flex flex-col justify-center">
                 <div className="flex-1">
                   <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={8}
                          dataKey="value"
                          stroke="none"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <ReTooltip />
                      </PieChart>
                   </ResponsiveContainer>
                 </div>
                 <div className="grid grid-cols-2 gap-4 mt-4">
                   {pieData.map(p => (
                     <div key={p.name} className="flex items-center gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-100 transition-colors hover:bg-slate-100">
                       <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
                       <div className="flex flex-col">
                         <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">{p.name}</span>
                         <span className="text-xs font-black text-slate-900">{((p.value / stats.totalGross) * 100).toFixed(0)}%</span>
                       </div>
                     </div>
                   ))}
                 </div>
               </div>
            </div>
          </div>

          <div className="bg-emerald-950 rounded-[2.5rem] p-10 text-white flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden relative group">
            <div className="relative z-10 flex-1">
              <div className="flex items-center gap-2 text-emerald-400 text-[10px] font-black uppercase tracking-[0.3em] mb-4">
                 <Trees className="w-5 h-5" /> Sustainability Impact
              </div>
              <h3 className="text-3xl font-black tracking-tight leading-tight">Equivalent to planting <span className="text-emerald-400">{(tons * 45).toLocaleString()}</span> trees per year.</h3>
              <p className="text-emerald-400/80 mt-3 text-sm font-medium">Your project has a direct environmental value that qualifies for additional voluntary market credits.</p>
            </div>
            <button className="bg-emerald-500 text-white px-10 py-5 rounded-[1.5rem] font-black flex items-center gap-3 hover:bg-emerald-400 transition-all shadow-2xl shadow-emerald-500/20 relative z-10 shrink-0 uppercase tracking-widest text-[10px]">
               Export ROI Deck <ArrowRight className="w-5 h-5" />
            </button>
            <div className="absolute -right-20 -bottom-20 opacity-5 pointer-events-none group-hover:scale-110 transition-transform duration-1000">
               <Trees className="w-[400px] h-[400px]" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Finance;