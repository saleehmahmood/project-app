import React, { useState, useMemo } from 'react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  ReferenceLine
} from 'recharts';
import { TrendingDown, Award, Factory, Trees, Zap, Info, ShieldCheck } from 'lucide-react';
import { MOCK_HISTORICAL_DATA, POLLUTION_THRESHOLDS } from '../constants';

type PollutantKey = 'pm25' | 'no2' | 'co2' | 'so2' | 'voc';

const Trends: React.FC = () => {
  const [selectedRange, setSelectedRange] = useState('6m');
  const [activePollutant, setActivePollutant] = useState<PollutantKey>('co2'); // Default to CO2 as requested for integration focus

  // Calculate reduction based on data
  const reductionStats = useMemo(() => {
    const first = MOCK_HISTORICAL_DATA[0][activePollutant];
    const last = MOCK_HISTORICAL_DATA[MOCK_HISTORICAL_DATA.length - 1][activePollutant];
    const percentage = ((first - last) / first) * 100;
    return Math.round(percentage);
  }, [activePollutant]);

  const getPollutantColor = (p: PollutantKey) => {
    switch(p) {
      case 'pm25': return '#3b82f6'; // Blue
      case 'no2': return '#f59e0b';  // Amber
      case 'co2': return '#10b981';  // Emerald
      case 'so2': return '#f43f5e';  // Rose
      case 'voc': return '#8b5cf6';  // Violet
      default: return '#3b82f6';
    }
  };

  const getImpactDescription = (p: PollutantKey) => {
    switch(p) {
      case 'co2': return "Carbon Dioxide levels are a primary indicator of facility ventilation efficiency and direct industrial combustion output.";
      case 'pm25': return "Fine particulate matter monitoring tracks the effectiveness of our air filtration and dust suppression systems.";
      case 'no2': return "Nitrogen Dioxide levels correlate directly with high-temperature industrial processes and vehicle emissions.";
      case 'so2': return "Sulfur Dioxide tracking identifies leaks in scrubbers and verifies the quality of fuel sources used in operations.";
      case 'voc': return "Volatile Organic Compounds monitoring ensures chemical storage integrity and solvent management compliance.";
      default: return "";
    }
  };

  const currentThreshold = POLLUTION_THRESHOLDS[activePollutant];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none uppercase">Analytics Core</h1>
          <p className="text-slate-500 mt-2 font-medium">Auditing historical emission performance and regulatory compliance.</p>
        </div>
        <div className="flex bg-white rounded-2xl border p-1 shadow-sm">
          {['1w', '1m', '6m', '1y'].map((range) => (
            <button
              key={range}
              onClick={() => setSelectedRange(range)}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                selectedRange === range ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-900'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </header>

      {/* Progress Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-emerald-600 rounded-[2rem] p-8 text-white shadow-xl relative overflow-hidden group">
          <div className="relative z-10">
            <div className="flex justify-between items-center mb-6">
              <TrendingDown className="w-10 h-10 opacity-80" />
              <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/20">
                Performance Delta
              </span>
            </div>
            <p className="text-emerald-100 text-sm font-medium opacity-80 uppercase tracking-widest">Reduction ({currentThreshold.label})</p>
            <h3 className="text-5xl font-black mt-1">-{reductionStats}%</h3>
            <p className="text-emerald-200/60 text-xs mt-2 font-bold uppercase tracking-wide">Jan Baseline vs. Current Avg</p>
          </div>
          <div className="absolute -right-8 -bottom-8 opacity-10 group-hover:scale-110 transition-transform duration-1000 rotate-12">
             <TrendingDown className="w-64 h-64" />
          </div>
        </div>

        <div className="bg-white rounded-[2rem] p-8 border shadow-sm flex flex-col justify-between hover:border-emerald-200 transition-all duration-300">
          <div className="flex items-center gap-4 text-slate-900 font-bold text-xl">
            <div className="bg-blue-100 p-3 rounded-2xl"><ShieldCheck className="w-7 h-7 text-blue-600" /></div>
            Audit Status
          </div>
          <p className="text-slate-600 text-sm mt-6 leading-relaxed font-medium">
            "{currentThreshold.label} levels have remained <span className="font-black text-slate-900 underline decoration-emerald-500">consistently within WHO safe zones</span> for 18 consecutive weeks following the Q1 infrastructure upgrade."
          </p>
          <div className="mt-8 pt-6 border-t border-slate-50 flex justify-between items-center">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Compliance Rating</span>
            <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Class A</span>
          </div>
        </div>

        <div className="bg-slate-900 rounded-[2rem] p-8 text-white shadow-xl overflow-hidden relative">
          <div className="relative z-10 h-full flex flex-col justify-between">
            <h4 className="font-bold text-slate-400 text-xs uppercase tracking-widest flex items-center gap-2">
               <Zap className="w-4 h-4 text-yellow-400" /> Data Integrity
            </h4>
            
            <div className="flex items-end gap-2 mb-4 h-20">
              {[45, 60, 85, 40, 95, 80, 98, 92, 90, 85, 99].map((h, i) => (
                <div key={i} className="flex-1 bg-white/5 rounded-full relative group cursor-help overflow-hidden">
                  <div 
                    className="absolute bottom-0 left-0 w-full bg-emerald-500 rounded-full transition-all duration-1000 group-hover:bg-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.5)]" 
                    style={{ height: `${h}%` }}
                  />
                </div>
              ))}
            </div>
            
            <div className="flex justify-between items-baseline">
               <span className="text-3xl font-black">99.8%</span>
               <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Uptime Certified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Trends Visualizer */}
      <div className="bg-white rounded-[2.5rem] p-10 border shadow-sm">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 mb-12">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
              {currentThreshold.label} Multi-Month Progression
            </h3>
            <p className="text-sm text-slate-500 font-medium max-w-md">
              {getImpactDescription(activePollutant)}
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2 p-1.5 bg-slate-50 rounded-2xl border">
            {(['pm25', 'no2', 'co2', 'so2', 'voc'] as PollutantKey[]).map((p) => (
              <button
                key={p}
                onClick={() => setActivePollutant(p)}
                className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  activePollutant === p 
                    ? 'bg-white text-slate-900 shadow-md border-slate-200 ring-1 ring-slate-200/50' 
                    : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'
                }`}
                style={activePollutant === p ? { borderBottom: `4px solid ${getPollutantColor(p)}` } : {}}
              >
                {POLLUTION_THRESHOLDS[p].label}
              </button>
            ))}
          </div>
        </div>

        <div className="h-[450px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={MOCK_HISTORICAL_DATA} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={getPollutantColor(activePollutant)} stopOpacity={0.4}/>
                  <stop offset="95%" stopColor={getPollutantColor(activePollutant)} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="time" 
                axisLine={false} 
                tickLine={false} 
                tick={{fill: '#94a3b8', fontSize: 13, fontWeight: 700}} 
                dy={15} 
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                domain={activePollutant === 'co2' ? [400, 'auto'] : ['auto', 'auto']}
                tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 500}} 
                tickFormatter={(value) => `${value}`}
                dx={-10}
              />
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '24px', 
                  border: 'none', 
                  boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.15)', 
                  padding: '24px',
                  background: '#1e293b',
                  color: '#fff'
                }}
                cursor={{ stroke: getPollutantColor(activePollutant), strokeWidth: 3, strokeDasharray: '8 8' }}
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    const val = payload[0].value as number;
                    return (
                      <div className="bg-[#1e293b] p-5 rounded-[1.5rem] border border-white/10 shadow-2xl">
                        <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-2">{label} Data Point</p>
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl font-black text-white">{val}</span>
                          <span className="text-sm font-bold text-slate-400">{currentThreshold.unit}</span>
                        </div>
                        <p className="text-[10px] mt-4 font-bold text-slate-500 uppercase tracking-tight">System Status: Optimal</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area 
                type="monotone" 
                dataKey={activePollutant} 
                stroke={getPollutantColor(activePollutant)} 
                strokeWidth={5}
                fillOpacity={1} 
                fill="url(#colorValue)" 
                animationDuration={2500}
                animationEasing="cubic-bezier(0.4, 0, 0.2, 1)"
              />
              <ReferenceLine y={currentThreshold.low} label={{ value: 'Low Threshold', position: 'insideRight', fill: '#94a3b8', fontSize: 10, fontWeight: 700 }} stroke="#94a3b8" strokeDasharray="3 3" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Milestone Footer */}
        <div className="mt-16 pt-10 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex items-start gap-6 bg-slate-50/50 p-6 rounded-[2rem] border border-slate-100 hover:shadow-inner transition-all group">
            <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center border shrink-0 group-hover:bg-slate-900 transition-colors">
              <Factory className="w-7 h-7 text-slate-400 group-hover:text-emerald-500 transition-colors" />
            </div>
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Operational Event</p>
              <p className="font-bold text-slate-900 text-lg">Infrastructure Modernization Q1</p>
              <p className="text-sm text-slate-500 mt-1 leading-relaxed">
                Implementation of AI-driven boiler controls resulted in a significant {activePollutant === 'co2' ? 'drop in fuel consumption and CO₂' : `reduction in ${currentThreshold.label}`} output.
              </p>
              <div className="flex items-center gap-2 mt-3 text-xs font-bold text-slate-400">
                <span className="bg-white px-2 py-1 rounded-md border">ID #OP-X24</span>
                <span>•</span>
                <span>Verified Jan 2024</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-start gap-6 bg-emerald-50/30 p-6 rounded-[2rem] border border-emerald-100/50 hover:shadow-inner transition-all group">
            <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center border shrink-0 group-hover:bg-emerald-600 transition-colors">
              <Trees className="w-7 h-7 text-emerald-500 group-hover:text-white transition-colors" />
            </div>
            <div>
              <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Impact Highlight</p>
              <p className="font-bold text-slate-900 text-lg">Carbon Credit Generation</p>
              <p className="text-sm text-slate-500 mt-1 leading-relaxed font-medium">
                Sustained low {currentThreshold.label} performance qualifies the facility for enhanced carbon offsets and high-tier ESG certification.
              </p>
              <div className="flex items-center gap-2 mt-3 text-xs font-bold text-emerald-600">
                <span className="bg-white px-2 py-1 rounded-md border border-emerald-100">MARKET READY</span>
                <span>•</span>
                <span>Q2 2024</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Trends;