import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  ChevronRight, 
  Trophy, 
  Calendar, 
  ShieldCheck,
  Zap,
  Info,
  Lightbulb,
  ArrowRight,
  ClipboardList,
  Wind,
  Settings
} from 'lucide-react';
import { MOCK_ROADMAP } from '../constants';

const Roadmap: React.FC = () => {
  const [steps, setSteps] = useState(MOCK_ROADMAP);
  const [activeCategory, setActiveCategory] = useState<'All' | 'ISO' | 'DOE' | 'ESG'>('All');

  const toggleStep = (id: string) => {
    setSteps(prev => prev.map(step => 
      step.id === id ? { ...step, completed: !step.completed } : step
    ));
  };

  const filteredSteps = activeCategory === 'All' 
    ? steps 
    : steps.filter(s => s.category === activeCategory);

  const completedCount = steps.filter(s => s.completed).length;
  const progress = Math.round((completedCount / steps.length) * 100);

  const doePillars = [
    {
      id: 'audit',
      title: "1. Energy Audit",
      icon: <ClipboardList className="w-5 h-5 text-blue-500" />,
      desc: "Mandatory ASHRAE Level II assessment to identify energy conservation measures.",
      reqs: ["Building Walkthrough", "Equipment Inventory", "Utility Bill Benchmarking"]
    },
    {
      id: 'hvac',
      title: "2. HVAC Optimization",
      icon: <Wind className="w-5 h-5 text-emerald-500" />,
      desc: "Upgrading systems and setpoints to reduce thermal waste by up to 30%.",
      reqs: ["VFD Implementation", "Envelope Sealing", "Smart Thermostat Control"]
    },
    {
      id: 'led',
      title: "3. Smart LED Retrofit",
      icon: <Zap className="w-5 h-5 text-amber-500" />,
      desc: "Implementation of intelligent lighting grids with occupancy and daylight sensors.",
      reqs: ["Daylight Harvesting", "Zone-based Control", "High-efficacy LED Swap"]
    }
  ];

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-700">
      <header>
        <h1 className="text-4xl font-black text-slate-900 tracking-tight leading-none uppercase">Compliance Strategy</h1>
        <p className="text-slate-500 mt-2 font-medium">Strategic roadmap for ISO 14001, DOE Energy Star, and Global ESG disclosure.</p>
      </header>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="bg-white rounded-[2.5rem] p-8 border shadow-sm text-center flex flex-col justify-center items-center">
            <div className="relative w-36 h-36 mb-6">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="72" cy="72" r="66"
                  fill="none" stroke="#f1f5f9" strokeWidth="12"
                />
                <circle
                  cx="72" cy="72" r="66"
                  fill="none" stroke="#10b981" strokeWidth="12"
                  strokeDasharray={414}
                  strokeDashoffset={414 - (414 * progress) / 100}
                  className="transition-all duration-1000 ease-in-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-black text-slate-900 leading-none">{progress}%</span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Ready</span>
              </div>
            </div>
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Global Milestone</h3>
        </div>

        <div className="lg:col-span-3 bg-[#121212] rounded-[2.5rem] p-10 text-white shadow-2xl flex flex-col md:flex-row items-center gap-10 relative overflow-hidden border border-white/5">
           <div className="relative z-10 flex-1">
             <div className="flex items-center gap-3 mb-6">
               <div className="bg-emerald-500 p-2.5 rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                 <ShieldCheck className="w-6 h-6 text-white" />
               </div>
               <h2 className="text-2xl font-black text-white uppercase tracking-tighter">DOE Energy Star Certification</h2>
             </div>
             <p className="text-slate-400 leading-relaxed mb-8 font-medium">
               The Department of Energy (DOE) recognizes facilities performing in the top 25% of energy efficiency. Certification requires a verified score of <span className="text-emerald-400 font-black">75 or higher</span> based on actual utility performance.
             </p>
             <div className="flex flex-wrap gap-4">
               <div className="bg-white/5 px-5 py-3 rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-300">
                 Baseline: Portfolio Manager
               </div>
               <div className="bg-white/5 px-5 py-3 rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-300">
                 Verify: Licensed PE Required
               </div>
               <div className="bg-white/10 px-5 py-3 rounded-2xl border border-emerald-500/30 text-[10px] font-black uppercase tracking-widest text-emerald-400">
                 Goal: 75+ Performance Score
               </div>
             </div>
           </div>
           <div className="hidden md:block absolute -right-16 -bottom-16 opacity-5 pointer-events-none group-hover:scale-110 transition-transform duration-1000">
             <Trophy className="w-80 h-80" />
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: DOE Technical Requirements Breakdown */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm space-y-8">
            <div className="flex items-center gap-3 border-b pb-6">
               <Settings className="w-6 h-6 text-slate-400" />
               <h4 className="font-black text-slate-900 uppercase tracking-widest text-sm">DOE Technical Requirements</h4>
            </div>
            
            <div className="space-y-10">
              {doePillars.map(pillar => (
                <div key={pillar.id} className="group">
                  <div className="flex items-center gap-4 mb-3">
                    <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 group-hover:bg-emerald-50 group-hover:border-emerald-100 transition-colors">
                      {pillar.icon}
                    </div>
                    <h5 className="font-black text-slate-800 text-sm uppercase tracking-tight">{pillar.title}</h5>
                  </div>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed mb-4">{pillar.desc}</p>
                  <div className="space-y-2">
                    {pillar.reqs.map((req, i) => (
                      <div key={i} className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                        {req}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-8 border-t border-slate-50">
               <button className="w-full bg-slate-50 border border-slate-100 text-slate-900 font-black text-[10px] uppercase tracking-widest py-4 rounded-2xl hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
                 Download DOE Technical Manual <ChevronRight className="w-4 h-4" />
               </button>
            </div>
          </div>

          <div className="bg-emerald-50 rounded-[2rem] p-8 border border-emerald-100 flex flex-col items-center text-center">
             <div className="bg-white p-4 rounded-2xl shadow-sm mb-6">
               <Lightbulb className="w-8 h-8 text-emerald-600" />
             </div>
             <h4 className="font-black text-emerald-900 uppercase tracking-tight">Certification Tip</h4>
             <p className="text-emerald-800/70 text-xs font-medium leading-relaxed mt-2">
               Regular HVAC maintenance alone can improve your Energy Star score by <span className="font-bold">5-10 points</span> without major capital investment.
             </p>
          </div>
        </div>

        {/* Right: Task List */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex bg-slate-100 p-1.5 rounded-[1.5rem] border border-slate-200 w-fit">
            {['All', 'ISO', 'DOE', 'ESG'].map(cat => (
              <button 
                key={cat} 
                onClick={() => setActiveCategory(cat as any)}
                className={`
                  px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all
                  ${activeCategory === cat ? 'bg-white text-slate-900 shadow-md ring-1 ring-slate-200/50' : 'text-slate-400 hover:text-slate-600'}
                `}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="space-y-6">
            {filteredSteps.map((step) => (
              <div 
                key={step.id} 
                className={`
                  bg-white rounded-[2rem] p-8 border shadow-sm transition-all duration-500 relative overflow-hidden group
                  ${step.completed ? 'opacity-60 bg-slate-50/50 border-slate-100' : 'hover:border-emerald-300 hover:shadow-xl'}
                `}
              >
                {step.completed && (
                  <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500" />
                )}
                <div className="flex items-start gap-6 relative z-10">
                  <button 
                    onClick={() => toggleStep(step.id)}
                    className={`mt-1 transition-all duration-300 scale-125 ${step.completed ? 'text-emerald-500' : 'text-slate-200 hover:text-emerald-400'}`}
                  >
                    {step.completed ? <CheckCircle2 className="w-8 h-8" /> : <Circle className="w-8 h-8" />}
                  </button>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-3">
                      <h4 className={`font-black text-xl tracking-tight transition-all ${step.completed ? 'text-slate-400' : 'text-slate-900 group-hover:text-emerald-600'}`}>
                        {step.title}
                      </h4>
                      <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${
                        step.category === 'ISO' ? 'bg-blue-50 text-blue-600 border-blue-100' : 
                        step.category === 'DOE' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-purple-50 text-purple-600 border-purple-100'
                      }`}>
                        {step.category} Standard
                      </span>
                    </div>
                    <p className={`text-sm leading-relaxed font-medium ${step.completed ? 'text-slate-400' : 'text-slate-500'}`}>
                      {step.description}
                    </p>
                    <div className="mt-8 pt-6 border-t border-slate-50 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="flex items-center gap-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <span className="flex items-center gap-2"><Calendar className="w-4 h-4" /> Compliance Target: {step.targetDate}</span>
                        <span className="hidden sm:block">•</span>
                        <span className="flex items-center gap-2"><Info className="w-4 h-4" /> Priority: High</span>
                      </div>
                      <button className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-colors ${step.completed ? 'text-slate-300' : 'text-emerald-600 hover:text-emerald-700'}`}>
                        Review Specifications <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-12 text-center bg-white rounded-[3rem] border border-dashed border-slate-200 mt-12 group hover:border-emerald-300 transition-colors">
             <div className="bg-emerald-50 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-8 transition-transform group-hover:scale-110 duration-700">
               <Trophy className="w-10 h-10 text-emerald-600" />
             </div>
             <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tighter">Energy Star Professional Submission</h3>
             <p className="text-slate-500 max-w-sm mx-auto mt-4 font-medium leading-relaxed">
               Once your facility achieves the required 75+ performance score and all technical audits are verified, you may unlock the final EPA/DOE portal for official certification.
             </p>
             <div className="mt-10 flex flex-col items-center gap-4">
                <button 
                  className={`
                    px-12 py-5 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] transition-all shadow-xl
                    ${progress < 75 ? 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none' : 'bg-[#1E1E1E] text-white hover:bg-emerald-600 hover:shadow-emerald-500/20'}
                  `} 
                  disabled={progress < 75}
                >
                  Unlock Final Verification Portal
                </button>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  {progress < 75 ? `Remaining: ${75 - progress}% readiness required` : 'Ready for Professional Audit'}
                </p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Roadmap;